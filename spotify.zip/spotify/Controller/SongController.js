const info = require('../models/song'); // Make sure this path points to your model

const SongController = {
    // Renders the main index page
    index: (req, res) => {
        res.render('index'); // Assuming you have a view engine set up
    },
    
    // Fetches all songs from the database and renders the display page
    display: (req, res) => {
        info.getAllInformation((err, results) => {
            if (err) {
                console.error(err);
                return res.status(500).send('Error retrieving songs'); // Error handling
            }
            res.render('display', { songs: results });
        });
    },

    // Saves a new song to the database
    save: (req, res) => {
        const data = req.body; // Data from the request body
        info.save(data, (err) => {
            if (err) {
                console.error(err);
                return res.status(500).send('Error saving song'); // Error handling
            }
            res.redirect('/'); // Redirect after successful save
        });
    }
};

module.exports = SongController;
