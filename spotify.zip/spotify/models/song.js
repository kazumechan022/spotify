const db = require('../config/music'); // Adjust the path to your music.js

const SongModel = {
    // Saves a new song to the database
    save: (data, callback) => {
        const query = "INSERT INTO songs (title, artist, album, lyrics, url, playlist) VALUES (?, ?, ?, ?, ?, ?)";
        db.query(query, [data.title, data.artist, data.album, data.lyrics, data.url, data.playlist], callback);
    },

    // Fetches all songs from the database
    getAllInformation: (callback) => {
        const query = "SELECT * FROM songs";
        db.query(query, callback);
    }
};

module.exports = SongModel;
