const express = require('express');
const SongController = require('../controller/SongController'); // Adjusted variable name for clarity
const router = express.Router();

// Route to render the main index page (home.ejs)
router.get('/', SongController.index); // Change to / for the home page

// Route to save a new song
router.post('/save', SongController.save);

// Route to display all songs
router.get('/display', SongController.display);

// Route for Search page
router.get('/search', (req, res) => {
    res.render('search'); // Renders search.ejs
});

// Route for Library page
router.get('/library', (req, res) => {
    res.render('library'); // Renders library.ejs
});

// Route for Account page
router.get('/account', (req, res) => {
    res.render('account'); // Renders account.ejs
});

module.exports = router; // Export the router
